#!/usr/bin/env python3
"""Apply source-level changes required to build the debug XBE on Windows."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def find_function_definition(source: str, signature_pattern: str, label: str) -> tuple[re.Match[str], int]:
    """Find a function signature followed by its opening brace, not a prototype."""
    for match in re.finditer(signature_pattern, source, re.MULTILINE):
        brace = match.end()
        while brace < len(source) and source[brace].isspace():
            brace += 1
        if brace < len(source) and source[brace] == "{":
            return match, brace
    raise RuntimeError(f"Could not locate {label} function definition")


def find_matching_brace(source: str, opening_brace: int, label: str) -> int:
    """Return the closing brace for a C function, ignoring comments and strings."""
    depth = 0
    in_string = False
    in_char = False
    escaped = False
    line_comment = False
    block_comment = False
    i = opening_brace
    while i < len(source):
        ch = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if line_comment:
            if ch == "\n":
                line_comment = False
        elif block_comment:
            if ch == "*" and nxt == "/":
                block_comment = False
                i += 1
        elif in_string or in_char:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif in_string and ch == '"':
                in_string = False
            elif in_char and ch == "'":
                in_char = False
        else:
            if ch == "/" and nxt == "/":
                line_comment = True
                i += 1
            elif ch == "/" and nxt == "*":
                block_comment = True
                i += 1
            elif ch == '"':
                in_string = True
            elif ch == "'":
                in_char = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return i
        i += 1
    raise RuntimeError(f"Unbalanced braces in {label} function")


def replace_function_body(source: str, signature_pattern: str, replacement: str, label: str) -> str:
    match, brace = find_function_definition(source, signature_pattern, label)
    end = find_matching_brace(source, brace, label)
    return source[:brace] + replacement + source[end + 1 :]


def normalize_winmain_xbe_validation(text: str) -> str:
    """Remove previous commented/invalid XBE checks and install one valid check."""
    load_anchor = '    printf("XBE loaded: %zu bytes\\n", xbe_size);'
    init_anchor = "    recomp_mod_compatibility_init();"
    if text.count(load_anchor) != 1:
        raise RuntimeError(
            f"Expected exactly one XBE-loaded anchor, found {text.count(load_anchor)}"
        )
    if text.count(init_anchor) != 1:
        raise RuntimeError(
            f"Expected exactly one mod-compatibility initialization anchor, found {text.count(init_anchor)}"
        )
    start = text.index(load_anchor) + len(load_anchor)
    end = text.index(init_anchor)
    if end <= start:
        raise RuntimeError("Invalid order of XBE validation anchors in WinMain")
    block = r'''
    if (!verify_retail_xbe(xbe_data, xbe_size)) {
        MessageBoxA(NULL,
                    "default.xbe does not contain a valid Xbox XBE header.\n",
                    "Mercenaries Recomp", MB_ICONERROR);
        free(xbe_data);
        return 1;
    }
    printf("XBE header validated (debug PC profile).\n");
    xbox_preview_log_event("session", "XBE header accepted by debug PC profile");

'''
    return text[:start] + block + text[end:]


def patch_main(main_path: Path, entry_point: str) -> None:
    text = main_path.read_text(encoding="utf-8-sig")
    macro = re.compile(r"^#define\s+MERCENARIES_ENTRY_POINT\s+0x[0-9A-Fa-f]+\s*$", re.MULTILINE)
    updated, count = macro.subn(f"#define MERCENARIES_ENTRY_POINT {entry_point}", text, count=1)
    if count != 1:
        raise RuntimeError("MERCENARIES_ENTRY_POINT macro not found or ambiguous")
    text = updated

    replacement = """{
    /* Debug-XBE profile: accept a structurally valid XBE header. The PC runtime
       does not require the Xbox retail SHA-256 identity or console signature. */
    return data != NULL && size >= 4u && memcmp(data, \"XBEH\", 4u) == 0;
}"""
    text = replace_function_body(
        text,
        r"static\s+BOOL\s+verify_retail_xbe\s*\([^)]*\)",
        replacement,
        "verify_retail_xbe",
    )
    # Strip old experimental/commented checks and any accidental nested function.
    text = normalize_winmain_xbe_validation(text)
    text = text.replace("Retail XBE SHA-256 verified.", "XBE header validated (debug PC profile).")
    text = text.replace("supported retail XBE SHA256 verified", "XBE header accepted by debug PC profile")
    text = text.replace("default.xbe is not the supported retail Mercenaries XBE.",
                        "default.xbe does not contain a valid Xbox XBE header.")
    text = text.replace("Required SHA-256:\\n", "")
    main_path.write_text(text, encoding="utf-8", newline="")


def patch_setup_launcher(path: Path) -> None:
    text = path.read_text(encoding="utf-8-sig")

    inventory = re.compile(
        r"if\s*\(\s*!scan_install_tree\(game_dir,\s*&file_count,\s*&total_bytes\)\s*\|\|\s*"
        r"file_count\s*!=\s*EXPECTED_RETAIL_FILE_COUNT\s*\|\|\s*"
        r"total_bytes\s*!=\s*EXPECTED_RETAIL_TOTAL_BYTES\s*\)\s*\{.*?\n\s*\}",
        re.DOTALL,
    )
    replacement_inventory = """if (!scan_install_tree(game_dir, &file_count, &total_bytes)) {
        _snwprintf_s(reason, reason_capacity, _TRUNCATE,
                     L\"The installed game directory could not be enumerated.\");
        return FALSE;
    }"""
    text, inv_count = inventory.subn(replacement_inventory, text, count=1)
    if inv_count != 1 and "The installed game directory could not be enumerated." not in text:
        if "EXPECTED_RETAIL_FILE_COUNT" in text or "EXPECTED_RETAIL_TOTAL_BYTES" in text:
            raise RuntimeError("Could not locate strict retail file-inventory validation in setup_launcher.c")
        # The local source may already have had strict inventory checks removed.

    marker_anchor = "    if (require_marker) {"
    marker_bypass = (
        "#if defined(MERCENARIES_DEBUG_XBE_BUILD)\n"
        "    /* A copied PC debug game-data folder need not carry the retail\n"
        "       launcher's installation marker. Essential assets are checked below. */\n"
        "    require_marker = FALSE;\n"
        "#endif\n"
        + marker_anchor
    )
    if "A copied PC debug game-data folder need not carry" not in text:
        if text.count(marker_anchor) != 1:
            raise RuntimeError("Could not locate unique install-marker validation in setup_launcher.c")
        text = text.replace(marker_anchor, marker_bypass, 1)

    hash_start = re.search(
        r"if\s*\(\s*!path_join\(path,\s*ARRAYSIZE\(path\),\s*game_dir,\s*L\"default\.xbe\"\)",
        text,
    )
    if hash_start:
        # Replace the whole if-block, whose close is the first balanced brace.
        brace = text.find("{", hash_start.start())
        depth = 0
        end = None
        for i in range(brace, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break
        if end is None:
            raise RuntimeError("Unbalanced default.xbe validation block in setup_launcher.c")
        replacement_hash = """if (!path_join(path, ARRAYSIZE(path), game_dir, L\"default.xbe\")) {
        _snwprintf_s(reason, reason_capacity, _TRUNCATE,
                     L\"The installed game is missing default.xbe.\");
        return FALSE;
    }
    if (!regular_nonempty_file(path)) {
        _snwprintf_s(reason, reason_capacity, _TRUNCATE,
                     L\"The installed game is missing a readable default.xbe file.\");
        return FALSE;
    }"""
        text = text[: hash_start.start()] + replacement_hash + text[end:]
    elif "missing a readable default.xbe" not in text:
        # The local tree may already have had the retail SHA check removed.
        if "default.xbe" not in text:
            raise RuntimeError("Could not locate default.xbe validation in setup_launcher.c")

    path.write_text(text, encoding="utf-8", newline="")


def patch_cmake(path: Path) -> None:
    text = path.read_text(encoding="utf-8-sig")
    option_line = 'option(MERCENARIES_DEBUG_XBE_BUILD "Build the PC runtime for a debug-format XBE" OFF)'
    if option_line not in text:
        anchor = "project(mercenaries_recomp C CXX)"
        if text.count(anchor) != 1:
            raise RuntimeError("Could not find unique CMake project() anchor")
        text = text.replace(anchor, anchor + "\n\n" + option_line, 1)

    runtime_definition = "target_compile_definitions(${PROJECT_NAME} PRIVATE MERCENARIES_DEBUG_XBE_BUILD=1)"
    if runtime_definition not in text:
        marker = "target_link_libraries(${PROJECT_NAME} PRIVATE xboxrecomp)"
        if text.count(marker) != 1:
            raise RuntimeError("Could not locate CMake runtime target for debug compile definition")
        block = (marker + "\n\nif(MERCENARIES_DEBUG_XBE_BUILD)\n"
                 "    " + runtime_definition + "\nendif()")
        text = text.replace(marker, block, 1)

    launcher_definition = "target_compile_definitions(mercenaries_launcher PRIVATE MERCENARIES_DEBUG_XBE_BUILD=1)"
    if launcher_definition not in text:
        launcher_anchor = ("target_compile_definitions(mercenaries_launcher PRIVATE\n"
                           "    _CRT_SECURE_NO_WARNINGS\n"
                           ")")
        if text.count(launcher_anchor) != 1:
            raise RuntimeError("Could not locate launcher compile-definition block")
        launcher_block = (launcher_anchor + "\nif(MERCENARIES_DEBUG_XBE_BUILD)\n"
                          "    " + launcher_definition + "\nendif()")
        text = text.replace(launcher_anchor, launcher_block, 1)

    path.write_text(text, encoding="utf-8", newline="")


def patch_manual_dispatch(path: Path) -> None:
    text = path.read_text(encoding="utf-8-sig")
    signature = "recomp_func_t recomp_lookup_manual(uint32_t xbox_va)"
    signature_pattern = re.escape(signature)
    match, brace = find_function_definition(text, signature_pattern, "recomp_lookup_manual")
    end = find_matching_brace(text, brace, "recomp_lookup_manual")
    body = text[brace + 1 : end]
    if "MERCENARIES_DEBUG_XBE_BUILD" in body:
        return
    wrapped = """{
#if defined(MERCENARIES_DEBUG_XBE_BUILD)
    /* Retail-address manual overrides are not valid for the debug XBE. */
    (void)xbox_va;
    return NULL;
#else""" + body + "#endif\n}"
    text = text[:brace] + wrapped + text[end + 1 :]
    path.write_text(text, encoding="utf-8", newline="")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", required=True, type=Path)
    parser.add_argument("--xbe-json", required=True, type=Path)
    parser.add_argument("--game-dir", required=True, type=Path)
    args = parser.parse_args()

    meta = json.loads(args.xbe_json.read_text(encoding="utf-8"))
    if meta.get("type") != "debug":
        raise SystemExit(f"Expected debug XBE metadata, got type={meta.get('type')!r}")
    entry = str(meta.get("entry_point", ""))
    if not re.fullmatch(r"0x[0-9A-Fa-f]{8}", entry):
        raise SystemExit(f"Invalid XBE entry point in metadata: {entry!r}")

    port = args.repo_root / "ports" / "mercenaries"
    patch_main(port / "src" / "main.c", entry)
    patch_setup_launcher(port / "src" / "setup_launcher.c")
    patch_cmake(port / "CMakeLists.txt")
    patch_manual_dispatch(port / "src" / "recomp_manual.c")
    print(f"[OK] Debug XBE source profile applied; native entry point is {entry}.")
    print("[OK] Retail SHA/inventory checks removed from the PC launcher/runtime path.")
    print("[OK] Retail manual guest-function dispatch disabled for the debug profile.")


if __name__ == "__main__":
    main()
